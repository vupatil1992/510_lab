package BankRecords;

//Abstract class Client.java

public abstract class Client {
	
	//Defining abstract method
	
	//Method to read data from csv file
	public abstract void readData();
	
	//Method to process data from csv file
	public abstract void processData();
	
	//Method to print process data from csv file
	public abstract void printData();
}
