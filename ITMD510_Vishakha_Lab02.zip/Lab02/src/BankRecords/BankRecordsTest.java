package BankRecords;
import java.util.Scanner;
public class BankRecordsTest {

	public static void main(String[] args)throws Exception {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int noOfRec;
		String isContinue;
		do {
		System.out.println("Please enter how many records you want to print");
		noOfRec= sc.nextInt();
		BankRecords bankRec = new BankRecords(noOfRec);
		
		//calling readData method which will read BankRececords.csv file
		bankRec.readData();
		System.out.println("Do you want to Continue YES/NO");
		
		isContinue =sc.next();
		
		if(isContinue.compareTo("yes")==0 || isContinue.compareTo("no")==0)
		{
			if(isContinue.compareTo("no")==0)
			{
				System.out.println("Thank You!");
				break;
			}
		}
		else
		{
			System.out.println("Incorrect input");
			System.out.println("Do you want to Continue YES/NO");
			
			isContinue =sc.next().toLowerCase();
		}
		
		}while(isContinue.compareTo("yes")==0);
		//initializing BankRecords class
		
		sc.close();
	}

}
