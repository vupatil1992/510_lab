package BankRecords;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BankRecords extends Client {
	
	//default constructor
	public BankRecords() {}
	int noOfRec;
	
	//parameterized constructor initializing number of record to display
	public BankRecords(int noOfRecords)
	{
		this.noOfRec= noOfRecords;
	}
	
	// defining all data elements
	String id,sex,region,married,car,save_act,current_act, mortgage, pep;
	ArrayList<List<String>> arrList = new ArrayList<>();
	BankRecords recObj[] = new BankRecords[570];
	int age,children,index=0;
	double income;
	
	

	//Method to read bank data
	public void readData()
	{
		//try block to read bank data
		try
		{
			File file = new File("bank-Detail.csv");
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line;
			
			//reading file line by line
			while((line=br.readLine())!= null)
			{
				arrList.add(Arrays.asList(line.split(",")));
				index++;
				
				//increases capacity of BankRecords class array if equals to 590
				if(index== recObj.length)
					incrementArrCapacity();
				
			}
			br.close();
		}
		catch(FileNotFoundException fileEx)
		{
			System.out.println("File Exception occured : "+ fileEx.getMessage());
			fileEx.printStackTrace();
		}
		catch(Exception ex)
		{
			System.out.println("Exception occured : "+ ex.getMessage());
			ex.printStackTrace();
		}
		processData();
	}
	
	//method to increase array capacity
	public void incrementArrCapacity()
	{
		recObj = Arrays.copyOf(recObj, recObj.length+10);
	}
	
	//Method to process the data from csv file
	public void processData()
	{
		int rec=0;
		for(List<String> recData: arrList)
		{
			recObj[rec]= new BankRecords();
			recObj[rec].setId(recData.get(0));
			recObj[rec].setAge(Integer.parseInt((recData.get(1))));
			recObj[rec].setSex(recData.get(2));
			recObj[rec].setRegion(recData.get(3));
			recObj[rec].setIncome(Double.parseDouble(recData.get(4)));
			recObj[rec].setMarried(recData.get(5));
			recObj[rec].setChildren(Integer.parseInt(recData.get(6)));
			recObj[rec].setCar(recData.get(7));
			recObj[rec].setSave_act(recData.get(8));
			recObj[rec].setCurrent_act(recData.get(9));
			recObj[rec].setMortgage(recData.get(10));
			recObj[rec].setPep(recData.get(11));
			
			rec++;
		}
		printData();
	}
	
	//Method to print the bank data
	public void printData()
	{
		
		System.out.println("Bank Data for future loan consideration:");
		System.out.println("----------------------------------------------------------------------------------------------------");
		System.out.println("|ID\t\t\tAGE\t\tSEX\t\tREGION\t\t INCOME\t\t  MORTGAGE |");
		System.out.println("----------------------------------------------------------------------------------------------------");
		 String finalRec;
		 
		 //loop to display record
		 for(int i=0;i< noOfRec;i++)
		 {
			 finalRec =String.format("|%s\t|\t%d\t|\t%s\t|\t%10s\t|%f\t|%10s|",recObj[i].getId(),recObj[i].getAge(),recObj[i].getSex(),
					 recObj[i].getRegion(),recObj[i].getIncome(),recObj[i].getMortgage());
			 System.out.println(finalRec);
		 }
		 System.out.println("----------------------------------------------------------------------------------------------------");
	}
	


//setters to set bank data elements
	public void setId(String id) {
		this.id = id;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public void setMarried(String married) {
		this.married = married;
	}

	public void setCar(String car) {
		this.car = car;
	}

	public void setSave_act(String save_act) {
		this.save_act = save_act;
	}

	public void setCurrent_act(String current_act) {
		this.current_act = current_act;
	}

	public void setMortgage(String mortgage) {
		this.mortgage = mortgage;
	}

	public void setPep(String pep) {
		this.pep = pep;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setChildren(int children) {
		this.children = children;
	}

	public void setIncome(double income) {
		this.income = income;
	}

	//getters to get all bank data elements
	public String getId() {
		return id;
	}

	public String getSex() {
		return sex;
	}

	public String getRegion() {
		return region;
	}

	public String getMarried() {
		return married;
	}

	public String getCar() {
		return car;
	}

	public String getSave_act() {
		return save_act;
	}

	public String getCurrent_act() {
		return current_act;
	}

	public String getMortgage() {
		return mortgage;
	}

	public String getPep() {
		return pep;
	}

	public int getAge() {
		return age;
	}

	public int getChildren() {
		return children;
	}

	public double getIncome() {
		return income;
	}
}